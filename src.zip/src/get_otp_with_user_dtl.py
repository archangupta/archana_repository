import json
from hashlib import sha256
from collections import Counter
from inputimeout import inputimeout, TimeoutOccurred
import tabulate, copy, time, datetime, requests, sys, os, random
from captcha import captcha_builder_manual, captcha_builder_auto
import uuid
#from get_otp import get_ios_otp, get_email_otp
import sqlite3
import pandas as pd
import re
import time,datetime
import imaplib
import email
from email.header import decode_header


#mobile=input("\nregistered Mobile number: ")


def collect_user_cred(mobile):
    # Get mobile
    #print("Fetching registered mobile.. ")
    user_mobile = mobile

    if len(user_mobile) < 10:
        print("TPlease enter valid mobile number. Exiting.")
        os.system("pause")
        sys.exit(1)

    
    # get input method to use
    input_option = input(
        """Auto enter OTP using SMS (iOS required) or email ? \nEnter 1 for SMS (iOS required) or 2 for Email. (Default 2) : """
    )

    if not input_option or int(input_option) not in [1, 2]:
        input_option = 2
    else:
        input_option = int(input_option)

    if input_option == 2:
        # Collect email detail
        input_dtls = get_email_detail()

    else:
        # Collect iOS detail
        input_dtls = get_ios_detail()

    
    collected_user_cred = {
        "user_mobile": user_mobile,
        "input_option": input_option,
        "input_dtls": input_dtls
    }

    return collected_user_cred


def get_email_detail():
    """
    This function
        1. Lists all states, prompts to select one,
        2. Lists all districts in that state, prompts to select required ones, and
        3. Returns the list of districts as list(dict)
    """
    email_id = input(
        """enter email id : """
    )

    password = input(
        """enter password : """
    )

    mailbox_folder = input(
        """enter mailbox folder (e.g. Inbox), Default is Inbox : """
    )

    if not mailbox_folder:
        mailbox_folder = 'Inbox'
    else:
        mailbox_folder = mailbox_folder

    reqd_email_detail = [
        {
            "email_id": email_id,
            "password": password,
            "mailbox_folder": mailbox_folder
        }
    ]
    print(f"Selected email detail: ")
    display_table(reqd_email_detail)
    return reqd_email_detail

def get_ios_detail():
    """
    This function
        1. Lists all states, prompts to select one,
        2. Lists all districts in that state, prompts to select required ones, and
        3. Returns the list of districts as list(dict)
    """
    ios_username = input(
        """enter iOS username : """
    )
    ios_sms_db="/Users/"+ ios_username+"/Library/Messages/chat.db"

    reqd_ios_detail = [
        {
            "ios_username": ios_username,
            "ios_sms_db"  : ios_sms_db
        }
    ]
    print(f"Selected iOS detail: ")
    display_table(reqd_ios_detail)
    return reqd_ios_detail

def display_table(dict_list):
    """
    This function
        1. Takes a list of dictionary
        2. Add an Index column, and
        3. Displays the data in tabular format
    """
    header = ["idx"] + list(dict_list[0].keys())
    rows = [[idx + 1] + list(x.values()) for idx, x in enumerate(dict_list)]
    print(tabulate.tabulate(rows, header, tablefmt="grid"))

def save_user_cred(filename, details):
#    print(
#        "\n================================= Save Info =================================\n"
#    )
    save_info = 'y' #input(
#        "Would you like to save this as a JSON file for easy use next time?: (y/n Default y): "
#    )
    save_info = save_info if save_info else "y"
    if save_info == "y":
        with open(filename, "w") as f:
            # JSON pretty save to file
            json.dump(details, f, sort_keys=True, indent=4)
        #print(f"Info saved to {filename} in {os.getcwd()}")


def get_saved_user_cred_info(filename):
    with open(filename, "r") as f:
        data = json.load(f)

    return data


def display_info_dict(details):
    for key, value in details.items():
        if isinstance(value, list):
            if all(isinstance(item, dict) for item in value):
                print(f"\t{key}:")
                display_table(value)
            else:
                print(f"\t{key}\t: {value}")
        else:
            print(f"\t{key}\t: {value}")


def confirm_and_proceed(collected_details):
    print(
        "\n================================= Confirm Info =================================\n"
    )
    display_info_dict(collected_details)

    confirm = input("\nProceed with above info (y/n Default y) : ")
    confirm = confirm if confirm else "y"
    if confirm != "y":
        print("Details not confirmed. Exiting process.")
        os.system("pause")
        sys.exit()

#collect_user_cred('9620818826')

def extract_otp(mobile):

    filename = 'user-details-'
    filename = filename + mobile + ".json"

    collected_user_cred = get_saved_user_cred_info(filename)
    if collected_user_cred['input_option'] == 1:
        ios_sms_db= collected_user_cred['input_dtls'][0]['ios_sms_db']
        #print(ios_sms_db)
        extracted_otp=get_ios_otp(ios_sms_db)
        #print("extracted otp is :", extracted_otp)
        return extracted_otp
    
    elif collected_user_cred['input_option'] == 2:
        #get_email_otp(username, password, GMAIL_FOLDER_NAME)
        email_username = collected_user_cred['input_dtls'][0]['email_id']
        email_password = collected_user_cred['input_dtls'][0]['password']
        email_mailbox_folder = '"'+collected_user_cred['input_dtls'][0]['mailbox_folder']+'"'
        #print(email_username, email_password, email_mailbox_folder)
        extracted_otp =get_email_otp(email_username, email_password, email_mailbox_folder)
        #print("extracted otp is :", extracted_otp)
        return extracted_otp


def get_ios_otp(IOS_SMS_DB):
    conn = sqlite3.connect(IOS_SMS_DB)
    #print('Reading SMS...')
    messages = pd.read_sql_query("select text, handle_id, date, is_sent, ROWID from message where text like '%Your OTP to register/access CoWIN is%' order by date desc limit 1", conn)
    messages.rename(columns={'ROWID': 'message_id'}, inplace=True)
    imessage_df = messages[['text', 'handle_id', 'date', 'is_sent', 'message_id']]

    verification_code_text = imessage_df['text'][0]
    if verification_code_text !='' :
        #print('verification_code_text is ',verification_code_text)
        extract_ios_otp=re.findall(r'\d+', verification_code_text)
        #print('extract_ios_otp is ', extract_ios_otp)
        ios_otp=extract_ios_otp[0]
        #print('ios_otp is ', ios_otp)
        #print(ios_otp)
        return ios_otp
    else:
        print("verification code not found")
        return None

def get_email_otp(username, password, GMAIL_FOLDER_NAME):
    #email_otp = []

    #add delay to allow for otp to be forwarded to email
    time.sleep(5)

    # create an IMAP4 class with SSL
    imap = imaplib.IMAP4_SSL("imap.gmail.com")
    # authenticate
    imap.login(username, password)

    status, messages = imap.select(GMAIL_FOLDER_NAME)
    # number of top emails to fetch
    N = 1
    # total number of emails
    #print(messages)
    messages = int(messages[0])

    for i in range(messages, messages - N, -1):
        # fetch the email message by ID
        res, msg = imap.fetch(str(i), "(RFC822)")
        for response in msg:
            if isinstance(response, tuple):
                # parse a bytes email into a message object
                msg = email.message_from_bytes(response[1])
                if msg.is_multipart():
                    # iterate over email parts
                    for part in msg.walk():
                        # extract content type of email
                        content_type = part.get_content_type()
                        content_disposition = str(part.get("Content-Disposition"))
                        try:
                            # get the email body
                            body = part.get_payload(decode=True).decode()
                        except:
                            pass
                        if content_type == "text/plain" and "attachment" not in content_disposition:
                            # print text/plain emails and skip attachments
                            # depending on your where your OTP is in the email, you will have to modify the string split method
                            #print(body)
                            extract_email_otp=re.findall(r'\d+', body)
                            email_otp = extract_email_otp[0]
                            #print(email_otp)

    
    imap.close()
    imap.logout()
    return email_otp



#otp=extract_otp()
#print('final otp is :',otp)


