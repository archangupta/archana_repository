
from selenium import webdriver
from time import sleep
from selenium.webdriver.chrome.options import Options
import os



def send_msg(filepath):

    user = "'Family'"
    msg = "your vaccine appointment has been scheduled. your appointment slip is attached below."

    options = Options()
    options.add_argument("--user-data-dir="+os.getcwd()+"/chrome-data")
    options.add_experimental_option("excludeSwitches", ["enable-automation"])
    options.add_experimental_option('useAutomationExtension', False)
    
    try:

        driver = webdriver.Chrome('/usr/local/bin/chromedriver', options=options)
        driver.maximize_window()
        driver.get('https://web.whatsapp.com/')

        found_user=False
        while not found_user:
            try:
                sleep(2)
                #click on the user name
                driver.find_element_by_xpath("//*[@title="+user+"]").click()
                found_user = True
            except Exception as e:
                print ('trying to find user..') 
                pass

        #type in Message and send
        driver.find_element_by_xpath('//*[@id="main"]/footer/div[1]/div[2]/div/div[2]').send_keys(msg)
        driver.find_element_by_xpath('//*[@id="main"]/footer/div[1]/div[3]/button/span').click()

        #click on attach icon
        driver.find_element_by_xpath('//*[@title = "Attach"]').click()

        #click on document on attach popup and select file
        image_box = driver.find_element_by_xpath('//input[@accept="*"]')
        image_box.send_keys(filepath)

        attach_file=False
        while not attach_file:
            try:
                #send attachment
                driver.find_element_by_xpath('//*[@data-icon="send"]').click()
                sleep(2)
                attach_file = True
            except Exception as e:
                print ('attaching file..') 
                pass


        print('File Sent to WhatsApp!')

        driver.close()
    except Exception as e:
        print (e) 
        #driver.close()
        print('exiting WhatsApp')
        return
#send_msg(os.getcwd()+'/appointmentslip_8088441935.pdf')